// Localização: src/com/gsmart/GSmartGui.java
package com.gsmart;

// Imports de configuração e lógica
import com.gsmart.Gui.windows.AlertRuleDialog;
import com.gsmart.config.AlertRule;
import com.gsmart.config.ConfigManager;
import com.gsmart.config.LogicConfig;
import com.gsmart.config.MetricConfig;
import com.gsmart.config.PipelineConfiguration;

// Imports das novas classes da GUI
import com.gsmart.Gui.AlertRuleTableModel;
import com.gsmart.Gui.MetricTableModel;
import com.gsmart.Gui.SystemMetricCellRenderer;

// Imports do pipeline e recursos
import com.gsmart.pipeline.PipelineManager;
import com.gsmart.resources.IDataSource;
import com.gsmart.sources.*;

// Imports das janelas auxiliares
import com.gsmart.Gui.windows.LogViewerWindow;
import com.gsmart.Gui.windows.ReconnectionLogViewer;
import com.gsmart.Gui.windows.TaskManagerWindow;

// Imports de bibliotecas externas e do Java
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * Classe principal da interface grafica (GUI) da aplicacao GSmart.
 *
 * Esta janela serve como o painel de controlo central, permitindo ao utilizador
 * configurar os pipelines de dados e as regras de alerta. A classe e responsavel por toda a
 * interacao com o utilizador e por orquestrar as operacoes de backend.
 *
 * @see com.gsmart.pipeline.PipelineManager
 */
public class GSmartGui extends JFrame {
    private static final Logger logger = LoggerFactory.getLogger(GSmartGui.class);

    // --- Componentes da UI (Pipeline) ---
    private final JComboBox<String> sourceSelector;
    private final JButton startButton;
    private final JButton stopAllButton;
    private final JButton monitoringButton;
    private final JButton loadKeysButton;
    private final JTextField pbiUrlField;
    private final JPanel thingsboardConfigPanel;
    private final JTextField thingsboardUrlField;
    private final JButton tbConnectButton;
    private final JLabel tbStatusLabel;
    private final JComboBox<DeviceProfile> deviceProfileSelector;
    private final JComboBox<Device> deviceSelector;
    private final JPanel databaseConfigPanel;
    private final JTextField dbUrlField;
    private final JTextField dbUserField;
    private final JPasswordField dbPasswordField;
    private final JButton dbConnectButton;
    private final JLabel dbStatusLabel;
    private final JComboBox<String> dbTableSelector;
    private final JTable metricsTable;
    private final MetricTableModel tableModel;
    private final JPanel sourceConfigCardPanel;
    private final JCheckBox runLogicCheckBox;

    // --- Componentes da UI (Alertas) ---
    private JTable alertRulesTable;
    private AlertRuleTableModel alertRuleTableModel;
    private List<AlertRule> alertRules; // Nossa lista principal de regras

    // --- Classes de Gestão e Janelas ---
    private final LogViewerWindow globalLogViewer;
    private final PipelineManager pipelineManager;
    private final ConfigManager configManager;
    private TaskManagerWindow taskManagerWindow;
    private ReconnectionLogViewer reconnectionLogViewer;

    // --- Outros ---
    private final OkHttpClient sharedOkHttpClient;
    private LogicConfig logicConfig;

    public GSmartGui(LogViewerWindow logViewer, PipelineManager pipelineManager) {
        // --- Inicialização de Variáveis ---
        this.globalLogViewer = logViewer;
        this.pipelineManager = pipelineManager;
        this.configManager = new ConfigManager();
        this.pipelineManager.setParentComponent(this);
        this.pipelineManager.setGlobalLogViewer(this.globalLogViewer);
        this.sharedOkHttpClient = new OkHttpClient();
        this.alertRules = new ArrayList<>(); // Inicializa a lista de regras

        // --- Configuração da Janela Principal ---
        setTitle("GSmart - Configurador de Pipeline e Alertas v5.0");
        setSize(850, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // =================================================================
        //  PAINEL DE CONFIGURAÇÃO DA PIPELINE (Separador 1)
        // =================================================================

        // --- Painel Superior (Fonte de Dados e Destino) ---
        JPanel topConfigurationPanel = new JPanel();
        topConfigurationPanel.setLayout(new BoxLayout(topConfigurationPanel, BoxLayout.Y_AXIS));
        JPanel sourceSelectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sourceSelectionPanel.setBorder(BorderFactory.createTitledBorder("Selecione a Fonte de Dados"));
        sourceSelectionPanel.add(new JLabel("Tipo de Fonte:"));
        String[] sources = {"Thingsboard API", "Banco de Dados Espelho"};
        sourceSelector = new JComboBox<>(sources);
        sourceSelectionPanel.add(sourceSelector);

        sourceConfigCardPanel = new JPanel(new CardLayout());
        thingsboardConfigPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbcTb = new GridBagConstraints();
        gbcTb.insets = new Insets(4, 5, 4, 5); gbcTb.anchor = GridBagConstraints.WEST;
        gbcTb.gridx = 0; gbcTb.gridy = 0; thingsboardConfigPanel.add(new JLabel("URL do Servidor:"), gbcTb);
        gbcTb.gridx = 1; thingsboardUrlField = new JTextField(); gbcTb.weightx = 1.0; gbcTb.fill = GridBagConstraints.HORIZONTAL; thingsboardConfigPanel.add(thingsboardUrlField, gbcTb);
        gbcTb.gridx = 2; tbConnectButton = new JButton("Conectar"); gbcTb.weightx = 0; gbcTb.fill = GridBagConstraints.NONE; thingsboardConfigPanel.add(tbConnectButton, gbcTb);
        gbcTb.gridx = 3; tbStatusLabel = new JLabel("Não conectado"); tbStatusLabel.setForeground(Color.GRAY); thingsboardConfigPanel.add(tbStatusLabel, gbcTb);
        gbcTb.gridx = 0; gbcTb.gridy = 1; thingsboardConfigPanel.add(new JLabel("Perfil de Dispositivo (Tipo):"), gbcTb);
        gbcTb.gridx = 1; deviceProfileSelector = new JComboBox<>(); gbcTb.gridwidth = 3; gbcTb.fill = GridBagConstraints.HORIZONTAL; deviceProfileSelector.setEnabled(false); thingsboardConfigPanel.add(deviceProfileSelector, gbcTb);
        gbcTb.gridx = 0; gbcTb.gridy = 2; gbcTb.gridwidth = 1; thingsboardConfigPanel.add(new JLabel("Dispositivo:"), gbcTb);
        gbcTb.gridx = 1; deviceSelector = new JComboBox<>(); gbcTb.gridwidth = 3; deviceSelector.setEnabled(false); thingsboardConfigPanel.add(deviceSelector, gbcTb);

        databaseConfigPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbcDb = new GridBagConstraints();
        gbcDb.insets = new Insets(2, 5, 2, 5); gbcDb.anchor = GridBagConstraints.WEST;
        gbcDb.gridx = 0; gbcDb.gridy = 0; gbcDb.gridwidth = 1; databaseConfigPanel.add(new JLabel("URL do Banco (JDBC):"), gbcDb);
        gbcDb.gridx = 1; gbcDb.gridy = 0; gbcDb.gridwidth = 3; gbcDb.weightx = 1.0; gbcDb.fill = GridBagConstraints.HORIZONTAL; dbUrlField = new JTextField(); databaseConfigPanel.add(dbUrlField, gbcDb);
        gbcDb.gridx = 4; gbcDb.gridy = 0; gbcDb.gridwidth = 1; gbcDb.fill = GridBagConstraints.NONE; dbConnectButton = new JButton("Conectar"); databaseConfigPanel.add(dbConnectButton, gbcDb);
        gbcDb.gridx = 5; gbcDb.gridy = 0; dbStatusLabel = new JLabel("Não conectado"); dbStatusLabel.setForeground(Color.GRAY); databaseConfigPanel.add(dbStatusLabel, gbcDb);
        gbcDb.gridx = 0; gbcDb.gridy = 1; gbcDb.gridwidth = 1; databaseConfigPanel.add(new JLabel("Usuário:"), gbcDb);
        gbcDb.gridx = 1; gbcDb.gridy = 1; gbcDb.gridwidth = 3; gbcDb.weightx = 1.0; gbcDb.fill = GridBagConstraints.HORIZONTAL; dbUserField = new JTextField(); databaseConfigPanel.add(dbUserField, gbcDb);
        gbcDb.gridx = 0; gbcDb.gridy = 2; gbcDb.gridwidth = 1; databaseConfigPanel.add(new JLabel("Senha:"), gbcDb);
        gbcDb.gridx = 1; gbcDb.gridy = 2; gbcDb.gridwidth = 3; gbcDb.weightx = 1.0; gbcDb.fill = GridBagConstraints.HORIZONTAL; dbPasswordField = new JPasswordField(""); databaseConfigPanel.add(dbPasswordField, gbcDb);
        gbcDb.gridx = 0; gbcDb.gridy = 3; gbcDb.gridwidth = 1; databaseConfigPanel.add(new JLabel("Tabela:"), gbcDb);
        gbcDb.gridx = 1; gbcDb.gridy = 3; gbcDb.gridwidth = 3; gbcDb.weightx = 1.0; gbcDb.fill = GridBagConstraints.HORIZONTAL; dbTableSelector = new JComboBox<>(); dbTableSelector.setEnabled(false); databaseConfigPanel.add(dbTableSelector, gbcDb);

        sourceConfigCardPanel.add(thingsboardConfigPanel, "Thingsboard API");
        sourceConfigCardPanel.add(databaseConfigPanel, "Banco de Dados Espelho");
        JPanel loadKeysPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        loadKeysButton = new JButton("Carregar Métricas da Fonte");
        loadKeysPanel.add(loadKeysButton);
        JPanel destinationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        destinationPanel.setBorder(BorderFactory.createTitledBorder("Configurar Destino dos Dados"));
        destinationPanel.add(new JLabel("URL de Push do Power BI:"));
        pbiUrlField = new JTextField(45);
        destinationPanel.add(pbiUrlField);
        topConfigurationPanel.add(sourceSelectionPanel);
        topConfigurationPanel.add(sourceConfigCardPanel);
        topConfigurationPanel.add(loadKeysPanel);
        topConfigurationPanel.add(destinationPanel);

        // --- Tabela de Métricas ---
        tableModel = new MetricTableModel();
        metricsTable = new JTable(tableModel);
        SystemMetricCellRenderer systemMetricRenderer = new SystemMetricCellRenderer();
        metricsTable.setDefaultRenderer(Object.class, systemMetricRenderer);
        metricsTable.setDefaultRenderer(Boolean.class, systemMetricRenderer);
        metricsTable.setFillsViewportHeight(true);
        metricsTable.getColumnModel().getColumn(0).setMaxWidth(60);
        metricsTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        metricsTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        metricsTable.getColumnModel().getColumn(3).setPreferredWidth(180);
        JScrollPane keysScrollPane = new JScrollPane(metricsTable);
        keysScrollPane.setBorder(BorderFactory.createTitledBorder("Selecionar, Mapear e Transformar Métricas"));

        // --- Painel de Ações da Pipeline ---
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 15));
        startButton = new JButton("Iniciar Pipeline");
        startButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        runLogicCheckBox = new JCheckBox("Executar Lógica Antiga");
        runLogicCheckBox.setToolTipText("Executa a lógica de negócio antiga das classes Manutencao e PrevisaoFalhas.");
        runLogicCheckBox.setSelected(false);
        actionPanel.add(startButton);
        actionPanel.add(runLogicCheckBox);

        JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        monitoringButton = new JButton("Central de Monitoramento");
        stopAllButton = new JButton("Parar Monitoramento");
        stopAllButton.setForeground(Color.RED);
        JPopupMenu logsPopupMenu = new JPopupMenu();
        JMenuItem generalLogItem = new JMenuItem("Log Geral");
        JMenuItem reconexLogItem = new JMenuItem("Log de Reconexão");
        logsPopupMenu.add(generalLogItem);
        logsPopupMenu.add(reconexLogItem);
        JButton logsButton = new JButton("Ver Logs");
        logsButton.addActionListener(e -> logsPopupMenu.show(logsButton, 0, logsButton.getHeight()));
        adminPanel.add(monitoringButton);
        adminPanel.add(stopAllButton);
        adminPanel.add(logsButton);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 0));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        bottomPanel.add(actionPanel, BorderLayout.WEST);
        bottomPanel.add(adminPanel, BorderLayout.CENTER);

        // --- Montagem do Painel do Separador 1 ---
        JPanel pipelineConfigPanel = new JPanel(new BorderLayout(5, 5));
        pipelineConfigPanel.add(topConfigurationPanel, BorderLayout.NORTH);
        pipelineConfigPanel.add(keysScrollPane, BorderLayout.CENTER);
        pipelineConfigPanel.add(bottomPanel, BorderLayout.SOUTH);

        // =================================================================
        //  PAINEL DE REGRAS DE ALERTA (Separador 2)
        // =================================================================

        JPanel alertRulesPanel = new JPanel(new BorderLayout(5, 5));
        alertRulesPanel.setBorder(BorderFactory.createTitledBorder("Configurador de Alertas Customizados"));

        alertRuleTableModel = new AlertRuleTableModel();
        alertRuleTableModel.setRules(this.alertRules);
        alertRulesTable = new JTable(alertRuleTableModel);
        alertRulesTable.setFillsViewportHeight(true);
        alertRulesTable.getColumnModel().getColumn(0).setMaxWidth(50);

        JScrollPane rulesScrollPane = new JScrollPane(alertRulesTable);
        alertRulesPanel.add(rulesScrollPane, BorderLayout.CENTER);

        JPanel ruleButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addRuleButton = new JButton("Adicionar Regra");
        JButton editRuleButton = new JButton("Editar Regra");
        JButton removeRuleButton = new JButton("Remover Regra");
        ruleButtonsPanel.add(addRuleButton);
        ruleButtonsPanel.add(editRuleButton);
        ruleButtonsPanel.add(removeRuleButton);
        alertRulesPanel.add(ruleButtonsPanel, BorderLayout.SOUTH);

        // =================================================================
        //  MONTAGEM FINAL COM SEPARADORES
        // =================================================================

        JTabbedPane mainTabbedPane = new JTabbedPane();
        mainTabbedPane.addTab("Configuração da Pipeline", pipelineConfigPanel);
        mainTabbedPane.addTab("Regras de Alerta", alertRulesPanel);

        // Adiciona o painel de separadores à janela principal
        this.setContentPane(mainTabbedPane);

        // =================================================================
        //  LISTENERS DE EVENTOS
        // =================================================================

        // Listeners da Pipeline
        sourceSelector.addItemListener(e -> toggleSourceFields());
        tbConnectButton.addActionListener(e -> connectToThingsboard());
        dbConnectButton.addActionListener(e -> connectToDatabase());
        deviceProfileSelector.addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadDevicesByProfile(); });
        loadKeysButton.addActionListener(e -> loadAvailableKeys());
        startButton.addActionListener(e -> launchPipeline());
        stopAllButton.addActionListener(e -> stopAllPipelines());
        monitoringButton.addActionListener(e -> showTaskManager());
        generalLogItem.addActionListener(e -> this.globalLogViewer.setVisible(true));
        reconexLogItem.addActionListener(e -> showReconnectionLog());

        // --- Listeners das Regras de Alerta ---

        addRuleButton.addActionListener(e -> {
            // Pega a lista de métricas disponíveis da outra tabela
            List<String> availableMetrics = tableModel.getSelectedMetrics().stream()
                    .map(MetricConfig::getOriginalName)
                    .collect(Collectors.toList());

            if (availableMetrics.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, carregue e selecione as métricas no separador 'Configuração da Pipeline' primeiro.", "Métricas não encontradas", JOptionPane.WARNING_MESSAGE);
                return;
            }

            AlertRuleDialog dialog = new AlertRuleDialog(this, "Adicionar Nova Regra de Alerta", availableMetrics);
            dialog.setVisible(true);

            AlertRule newRule = dialog.getAlertRule();
            if (newRule != null) {
                alertRuleTableModel.addRule(newRule);
            }
        });

        editRuleButton.addActionListener(e -> {
            int selectedRow = alertRulesTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, selecione uma regra na tabela para editar.", "Nenhuma Regra Selecionada", JOptionPane.WARNING_MESSAGE);
                return;
            }

            AlertRule ruleToEdit = alertRuleTableModel.getRuleAt(selectedRow);
            List<String> availableMetrics = tableModel.getSelectedMetrics().stream()
                    .map(MetricConfig::getOriginalName)
                    .collect(Collectors.toList());

            AlertRuleDialog dialog = new AlertRuleDialog(this, "Editar Regra de Alerta", availableMetrics);
            dialog.setAlertRule(ruleToEdit); // Pré-preenche o formulário
            dialog.setVisible(true);

            AlertRule updatedRule = dialog.getAlertRule();
            if (updatedRule != null) {
                alertRuleTableModel.updateRule(selectedRow, updatedRule);
            }
        });

        removeRuleButton.addActionListener(e -> {
            int selectedRow = alertRulesTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, selecione uma regra na tabela para remover.", "Nenhuma Regra Selecionada", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this, "Tem a certeza que deseja remover a regra selecionada?", "Confirmar Remoção", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                alertRuleTableModel.removeRule(selectedRow);
            }
        });

        // Listener da Janela
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveConfiguration();
            }
        });

        // Carregamento inicial
        toggleSourceFields();
        loadConfiguration();
    }

    // --- MÉTODOS EXISTENTES (sem abreviação) ---

    private void showReconnectionLog() {
        if (reconnectionLogViewer == null || !reconnectionLogViewer.isDisplayable()) {
            reconnectionLogViewer = new ReconnectionLogViewer();
        }
        reconnectionLogViewer.loadLogFile();
        reconnectionLogViewer.setVisible(true);
        reconnectionLogViewer.toFront();
    }

    private void loadConfiguration() {
        logger.info("Carregando configurações salvas...");
        Properties props = configManager.loadProperties();
        thingsboardUrlField.setText(props.getProperty("thingsboard.url", "http://10.8.0.5:8080"));
        dbUrlField.setText(props.getProperty("db.url", "jdbc:postgresql://localhost:5432/seu_banco"));
        dbUserField.setText(props.getProperty("db.user", "postgres"));
        pbiUrlField.setText(props.getProperty("powerbi.url", ""));
        sourceSelector.setSelectedItem(props.getProperty("source.last", "Thingsboard API"));
        runLogicCheckBox.setSelected(Boolean.parseBoolean(props.getProperty("logic.run", "false")));
    }

    private void saveConfiguration() {
        logger.info("Salvando configurações antes de fechar...");
        Properties props = new Properties();
        props.setProperty("thingsboard.url", thingsboardUrlField.getText());
        props.setProperty("db.url", dbUrlField.getText());
        props.setProperty("db.user", dbUserField.getText());
        props.setProperty("powerbi.url", pbiUrlField.getText());
        props.setProperty("source.last", (String) sourceSelector.getSelectedItem());
        props.setProperty("logic.run", String.valueOf(runLogicCheckBox.isSelected()));
        configManager.saveProperties(props);
    }

    private void launchPipeline() {
        if (metricsTable.isEditing()) {
            metricsTable.getCellEditor().stopCellEditing();
        }
        try {
            String pbiUrl = pbiUrlField.getText().trim();
            if (pbiUrl.isEmpty() || !pbiUrl.toLowerCase().startsWith("http")) {
                JOptionPane.showMessageDialog(this, "Por favor, insira uma URL de Push do Power BI válida (deve começar com http ou https).", "Erro de Configuração", JOptionPane.ERROR_MESSAGE);
                return;
            }
            List<MetricConfig> selectedConfigs = tableModel.getSelectedMetrics();
            if (selectedConfigs.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nenhuma métrica foi selecionada para envio!", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean runLogic = runLogicCheckBox.isSelected();
            if (runLogic && (this.logicConfig == null)) {
                JOptionPane.showMessageDialog(this, "A caixa 'Executar Lógica Antiga' está marcada, mas a configuração não foi feita.\nPor favor, carregue as métricas novamente e configure a lógica.", "Erro de Configuração", JOptionPane.ERROR_MESSAGE);
                return;
            }

            IDataSource selectedDataSource = createSelectedDataSource(selectedConfigs.stream().map(MetricConfig::getOriginalName).collect(Collectors.toList()));
            // Nota: Precisaremos de passar a lista 'alertRules' para o PipelineConfiguration no futuro
            PipelineConfiguration config = new PipelineConfiguration(selectedDataSource, pbiUrl, selectedConfigs, this.logicConfig, this.globalLogViewer, runLogic, this.alertRules);
            pipelineManager.launchPipeline(config);
            JOptionPane.showMessageDialog(this, "Pipeline para '" + selectedDataSource.getSourceName() + "' iniciada em segundo plano.\nAbra a 'Central de Monitoramento' para visualizar.", "Pipeline Iniciada", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            logger.error("Falha ao preparar a pipeline: {}", e.getMessage(), e);
            JOptionPane.showMessageDialog(this, "Falha ao preparar a pipeline:\n" + e.getMessage(), "Erro Crítico", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void stopAllPipelines() {
        pipelineManager.stopAllPipelines();
    }

    private void showTaskManager() {
        if (taskManagerWindow == null || !taskManagerWindow.isDisplayable()) {
            taskManagerWindow = new TaskManagerWindow(this.pipelineManager);
            taskManagerWindow.setLocationRelativeTo(this);
        }
        taskManagerWindow.setVisible(true);
        taskManagerWindow.toFront();
    }

    private void toggleSourceFields() {
        CardLayout cl = (CardLayout) (sourceConfigCardPanel.getLayout());
        String selectedSource = (String) sourceSelector.getSelectedItem();
        if (selectedSource != null) {
            cl.show(sourceConfigCardPanel, selectedSource);
        }
    }

    private String getThingsboardUrl() {
        String url = thingsboardUrlField.getText().trim();
        if (url.isEmpty()) {
            JOptionPane.showMessageDialog(this, "A URL do Servidor ThingsBoard não pode estar vazia.", "Erro de Configuração", JOptionPane.ERROR_MESSAGE);
            throw new IllegalStateException("URL do ThingsBoard não fornecida.");
        }
        return url;
    }

    private void connectToThingsboard() {
        tbStatusLabel.setText("Conectando...");
        tbStatusLabel.setForeground(Color.ORANGE);
        tbConnectButton.setEnabled(false);
        new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() {
                try {
                    return new ThingsBoardSource(getThingsboardUrl(), null, null, sharedOkHttpClient).testConnection();
                } catch (Exception e) {
                    return false;
                }
            }
            @Override
            protected void done() {
                try {
                    if (get()) {
                        tbStatusLabel.setText("Conectado");
                        tbStatusLabel.setForeground(new Color(0, 128, 0));
                        deviceProfileSelector.setEnabled(true);
                        loadDeviceProfiles();
                    } else {
                        throw new Exception("Falha na autenticação ou URL incorreta.");
                    }
                } catch (Exception e) {
                    tbStatusLabel.setText("Falha!");
                    tbStatusLabel.setForeground(Color.RED);
                } finally {
                    tbConnectButton.setEnabled(true);
                }
            }
        }.execute();
    }

    private void connectToDatabase() {
        dbStatusLabel.setText("Conectando...");
        dbStatusLabel.setForeground(Color.ORANGE);
        dbConnectButton.setEnabled(false);
        new SwingWorker<List<String>, Void>() {
            @Override
            protected List<String> doInBackground() throws Exception {
                DatabaseSource tempSource = new DatabaseSource(dbUrlField.getText().trim(), dbUserField.getText().trim(), new String(dbPasswordField.getPassword()), null, null);
                if (tempSource.testConnection()) {
                    return tempSource.getAvailableTables();
                } else {
                    throw new SQLException("Não foi possível validar a conexão com o banco de dados.");
                }
            }
            @Override
            protected void done() {
                try {
                    List<String> tables = get();
                    dbStatusLabel.setText("Conectado");
                    dbStatusLabel.setForeground(new Color(0, 128, 0));
                    dbTableSelector.removeAllItems();
                    tables.forEach(dbTableSelector::addItem);
                    dbTableSelector.setEnabled(true);
                } catch (Exception e) {
                    dbStatusLabel.setText("Falha!");
                    dbStatusLabel.setForeground(Color.RED);
                    JOptionPane.showMessageDialog(GSmartGui.this, "Não foi possível conectar ao Banco de Dados:\n" + e.getCause().getMessage(), "Erro de Conexão", JOptionPane.ERROR_MESSAGE);
                } finally {
                    dbConnectButton.setEnabled(true);
                }
            }
        }.execute();
    }

    private void loadAvailableKeys() {
        loadKeysButton.setEnabled(false);
        loadKeysButton.setText("Carregando...");
        String selectedSource = (String) sourceSelector.getSelectedItem();
        try {
            if ("Thingsboard API".equals(selectedSource)) {
                Device selectedDevice = (Device) deviceSelector.getSelectedItem();
                if (selectedDevice == null) {
                    JOptionPane.showMessageDialog(this, "Por favor, conecte e selecione um dispositivo primeiro.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    setLoadButtonReady();
                    return;
                }
                new SwingWorker<List<String>, Void>() {
                    @Override
                    protected List<String> doInBackground() throws Exception {
                        return new ThingsBoardSource(getThingsboardUrl(), selectedDevice.id(), null, sharedOkHttpClient).getAvailableKeys();
                    }
                    @Override
                    protected void done() {
                        handleKeysLoaded(this);
                    }
                }.execute();
            } else if ("Banco de Dados Espelho".equals(selectedSource)) {
                String selectedTable = (String) dbTableSelector.getSelectedItem();
                if (selectedTable == null) {
                    JOptionPane.showMessageDialog(this, "Por favor, conecte e selecione uma tabela primeiro.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    setLoadButtonReady();
                    return;
                }
                new SwingWorker<List<String>, Void>() {
                    @Override
                    protected List<String> doInBackground() throws Exception {
                        String dbUrl = dbUrlField.getText().trim();
                        String dbUser = dbUserField.getText().trim();
                        String dbPassword = new String(dbPasswordField.getPassword());
                        return new DatabaseSource(dbUrl, dbUser, dbPassword, selectedTable, null).getAvailableColumns(selectedTable);
                    }
                    @Override
                    protected void done() {
                        handleKeysLoaded(this);
                    }
                }.execute();
            }
        } catch (IllegalStateException e) {
            logger.error("Pré-condição para carregar chaves falhou: {}", e.getMessage());
            setLoadButtonReady();
        }
    }

    private void handleKeysLoaded(SwingWorker<List<String>, Void> worker) {
        try {
            List<String> keys = worker.get();
            if (keys.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nenhuma métrica ou coluna foi encontrada para esta fonte!", "Aviso", JOptionPane.WARNING_MESSAGE);
                tableModel.clearMetrics();
                return;
            }

            runLogicCheckBox.setSelected(false);
            this.logicConfig = null;
            logger.info("Lógica de negócio temporariamente desativada por padrão.");

            List<MetricConfig> configs = keys.stream().map(MetricConfig::new).collect(Collectors.toList());
            configs.add(0, new MetricConfig("OrigemDados", true, true));
            configs.add(0, new MetricConfig("HdDev", true, true));
            configs.add(0, new MetricConfig("timestamp", true, true));
            configs.add(0, new MetricConfig("AlertaCritico", true, true));
            tableModel.setMetrics(configs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Falha ao carregar as métricas/colunas:\n" + e.getCause().getMessage(), "Erro de Conexão", JOptionPane.ERROR_MESSAGE);
        } finally {
            setLoadButtonReady();
        }
    }

    private void setLoadButtonReady() {
        loadKeysButton.setEnabled(true);
        loadKeysButton.setText("Carregar Métricas da Fonte");
    }

    private IDataSource createSelectedDataSource(List<String> originalKeys) throws Exception {
        String selectedSource = (String) sourceSelector.getSelectedItem();
        if ("Thingsboard API".equals(selectedSource)) {
            String tbUrl = getThingsboardUrl();
            Device selectedDevice = (Device) deviceSelector.getSelectedItem();
            if (selectedDevice == null) {
                throw new IllegalStateException("Nenhum dispositivo do ThingsBoard foi selecionado.");
            }
            ThingsBoardSource tbSource = new ThingsBoardSource(tbUrl, selectedDevice.id(), originalKeys, sharedOkHttpClient);
            tbSource.testConnectionAndThrow();
            return tbSource;

        } else if ("Banco de Dados Espelho".equals(selectedSource)) {
            String dbUrl = dbUrlField.getText().trim();
            String dbUser = dbUserField.getText().trim();
            String dbPassword = new String(dbPasswordField.getPassword());
            String dbTable = (String) dbTableSelector.getSelectedItem();
            if (dbTable == null) {
                throw new IllegalStateException("Nenhuma tabela do banco de dados foi selecionada.");
            }
            DatabaseSource dbSource = new DatabaseSource(dbUrl, dbUser, dbPassword, dbTable, originalKeys);
            dbSource.testConnectionAndThrow();
            return dbSource;
        }
        throw new IllegalStateException("Nenhuma fonte de dados válida foi selecionada.");
    }

    private String showDropdownDialog(List<String> options, String title, String message) {
        if (options == null || options.isEmpty()) return null;
        Object[] possibilities = options.toArray();
        return (String) JOptionPane.showInputDialog(this, message, title, JOptionPane.PLAIN_MESSAGE, null, possibilities, options.get(0));
    }

    private void loadDeviceProfiles() {
        Object previouslySelected = deviceProfileSelector.getSelectedItem();
        tbConnectButton.setEnabled(false);
        new SwingWorker<List<DeviceProfile>, Void>() {
            @Override
            protected List<DeviceProfile> doInBackground() throws Exception {
                return new ThingsBoardSource(getThingsboardUrl(), null, null, sharedOkHttpClient).getDeviceProfiles();
            }

            @Override
            protected void done() {
                try {
                    List<DeviceProfile> profiles = get();
                    deviceProfileSelector.removeAllItems();
                    profiles.forEach(deviceProfileSelector::addItem);
                    if (previouslySelected != null) {
                        for (int i = 0; i < deviceProfileSelector.getItemCount(); i++) {
                            if (Objects.equals(deviceProfileSelector.getItemAt(i), previouslySelected)) {
                                deviceProfileSelector.setSelectedIndex(i);
                                break;
                            }
                        }
                    }
                } catch (Exception e) {
                    logger.error("Falha ao buscar perfis de dispositivo: {}", e.getMessage(), e);
                    tbStatusLabel.setText("Falha!");
                    tbStatusLabel.setForeground(Color.RED);
                } finally {
                    tbConnectButton.setEnabled(true);
                }
            }
        }.execute();
    }

    private void loadDevicesByProfile() {
        DeviceProfile selectedProfile = (DeviceProfile) deviceProfileSelector.getSelectedItem();
        if (selectedProfile == null) {
            deviceSelector.removeAllItems();
            return;
        }
        deviceSelector.setEnabled(false);
        new SwingWorker<List<Device>, Void>() {
            @Override
            protected List<Device> doInBackground() throws Exception {
                return new ThingsBoardSource(getThingsboardUrl(), null, null, sharedOkHttpClient).getDevicesByProfileId(selectedProfile.id());
            }

            @Override
            protected void done() {
                try {
                    List<Device> devices = get();
                    deviceSelector.removeAllItems();
                    devices.forEach(deviceSelector::addItem);

                    deviceSelector.setEnabled(true);
                } catch (Exception e) {
                    logger.error("Falha ao buscar dispositivos para o perfil '{}': {}", selectedProfile.name(), e.getMessage(), e);
                }
            }
        }.execute();
    }
}